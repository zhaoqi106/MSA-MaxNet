# MSA-MaxNet
This repository contains official implementation for the paper titled "MSA-MaxNet: Multi-scale Attention Enhanced Multi-Axis Vision Transformer Network for Medical Image Segmentation"


### Architecture
![model](figures/model.jpg)

### visualization of synapse

![visualization](figures/synapse_visualization.jpg)



## 1. Prepare data

- [Synapse multi-organ segmentation] The Synapse datasets we used are provided by TransUnet's authors. [Get processed data in this link] (https://drive.google.com/drive/folders/1ACJEoTp-uqfFJ73qS3eUObQh52nGuzCd). 
- [ACDC cardiac segmentation]



## 2. Environment
- We recommend an evironment with python >= 3.8, pytorch >=2.0.0.

## 3. Train 

### Run the training script
```
python train_synapse.py --root_path [path of dataset]
```
For example, for Synapse dataset, run the following command:
```
python train_synapse.py --root_path ./data/Synapse
```
OR
```
python train_synapse.py --root_path ./data/Synapse  --cfg configs/MSA_MaxNet_small_synapse.yaml
```
For ACDC dataset, run the following command:
```
python train_acdc.py --root_path ./data/ACDC
```
For Kvasir-SEG dataset, run the following command:
```
python train_kvseg.py 
```
## 4. Evaluate Pretrained Models
### Run the evaluating script
```
python test.py --volume_path [path of dataset] --save_checkpoint [path of trained checkpoint]
```
For example, for Synapse dataset, run the following command:
```
python test_synapse.py --volume_path ./data/Synapse --save_checkpoint ./trained_ckpt/out/best_train_model.pth
```
For ACDC dataset, run the following command:

```
python test_acdc.py --volume_path ./data/ACDC --save_checkpoint ./trained_ckpt/out/best_model.pth
```


## Acknowledgements

This code is built on the top of [Swin UNet](https://github.com/HuCaoFighting/Swin-Unet)、[MERIT](https://github.com/SLDGroup/MERIT) and [AgileFormer](https://github.com/sotiraslab/AgileFormer) , we thank to their efficient and neat codebase. 


