import os
import random
import numpy as np
import torch
from scipy import ndimage
from scipy.ndimage.interpolation import zoom
from torch.utils.data import Dataset
import cv2
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from PIL import Image

def normalize_to(image):
    """
    将任意范围内的 numpy 数组线性映射为 [0, 255] 的整数值。

    Args:
        image (np.ndarray): 输入的 numpy 数组，值在任意范围内。

    Returns:
        np.ndarray: 转换后的 [0, 255] 范围内的 uint8 类型的 numpy 数组。
    """
    # 计算输入数据的最小值和最大值
    min_val = np.min(image)
    max_val = np.max(image)

    # 线性归一化，将任意范围的值映射到 [0, 255]
    image_normalized = (image - min_val) / (max_val - min_val)

    # 将结果转换为 uint8 类型
    return image_normalized

def visualize_image(image, title=None):
    """
    Visualize an image, whether it's in PIL, numpy, or torch.Tensor format.

    Args:
        image: The image to visualize. Can be a PIL.Image, numpy array, or torch.Tensor.
        title: Optional title for the image.
    """
    if isinstance(image, Image.Image):  # If the image is a PIL image
        plt.imshow(image)
        plt.axis('off')

    elif isinstance(image, np.ndarray):  # If the image is a numpy array
        if image.ndim == 2:  # Grayscale image
            plt.imshow(image, cmap='gray')
        else:
            plt.imshow(image)
        plt.axis('off')

    elif isinstance(image, torch.Tensor):  # If the image is a torch.Tensor
        if image.ndimension() == 3:
            # Assume the tensor is in CxHxW format (e.g., 3x224x224 for color image)
            image = image.permute(1, 2, 0)  # Convert to HxWxC for visualization
        image = image.cpu().numpy()  # Convert to numpy for plotting
        if image.ndim == 2:  # Grayscale image
            plt.imshow(image, cmap='gray')
        else:
            plt.imshow(image)
        plt.axis('off')

    else:
        raise TypeError("Unsupported image type. Must be PIL, numpy, or torch.Tensor.")

    if title:
        plt.title(title)
    plt.show()
def random_crop(image, label, crop_height=32, crop_width=32):
    """
    从输入的图像和标签（NumPy 数组）中随机裁剪一个区域，并将裁剪后的图像和标签调整回原始尺寸。

    Args:
        image (np.ndarray): 输入的图像数组，形状为 (H, W, C) 或 (H, W)。
        label (np.ndarray): 输入的标签数组，形状应与图像相同。
        crop_height (int): 裁剪区域的高度。
        crop_width (int): 裁剪区域的宽度。

    Returns:
        (np.ndarray, np.ndarray): 调整回原始尺寸的图像和标签。
    """
    img_height, img_width = image.shape[:2]
    crop_height = int(img_height *0.2)
    crop_width = int(img_width *0.2)
    crop_height = img_height - crop_height
    crop_width = img_width - crop_width

    if crop_height > img_height or crop_width > img_width:
        raise ValueError("裁剪区域的大小不能大于输入图像的大小")

    # 随机选择裁剪区域的左上角位置
    top = np.random.randint(0, img_height - crop_height + 1)
    left = np.random.randint(0, img_width - crop_width + 1)

    # 进行裁剪
    image = image[top:top + crop_height, left:left + crop_width]
    label = label[top:top + crop_height, left:left + crop_width]

    # 调整回原始尺寸
    # image = cv2.resize(image,(img_height,img_width),interpolation=cv2.INTER_LINEAR)
    # label = cv2.resize(label,(img_height,img_width),interpolation=cv2.INTER_NEAREST)
    # x, y= image.shape
    image = zoom(image, (img_height / crop_height, img_width / crop_width), order=3)  # why not 3?
    label = zoom(label, (img_height / crop_height, img_width / crop_width), order=0)



    return image,label


import numpy as np
from PIL import Image
import torchvision.transforms.functional as F


def random_affine_grayscale(image, label):
    # 确保输入图像是PIL Image格式
    if isinstance(image, np.ndarray):
        # image = (image*255).astype(np.uint8)
        image = (normalize_to(image) * 255).astype(np.uint8)
        # image = (normalize_to(image) * 255)
        image = Image.fromarray(image)
    if isinstance(label, np.ndarray):
        label = label.astype(np.uint8)
        label = Image.fromarray(label,mode="L")

    # 随机生成仿射变换参数
    angle = np.random.uniform(-30, 30)  # 随机旋转角度
    translate = (np.random.uniform(-10, 10), np.random.uniform(-10, 10))  # 随机平移
    scale = np.random.uniform(0.8, 1.2)  # 随机缩放
    shear = np.random.uniform(-10, 10)  # 随机剪切角度

    # 应用仿射变换到图像和掩码
    image = F.affine(image, angle=angle, translate=translate, scale=scale, shear=shear, fill=0)
    label = F.affine(label, angle=angle, translate=translate, scale=scale, shear=shear, interpolation=Image.NEAREST,fill=0)

    # 随机颜色变化
    brightness_factor = np.random.uniform(0.8, 1.2)  # 随机亮度变化
    contrast_factor = np.random.uniform(0.8, 1.2)  # 随机对比度变化

    if random.random() > 0.5:
        image = F.adjust_brightness(image, brightness_factor)
    if random.random() > 0.5:
        image = F.adjust_contrast(image, contrast_factor)

    image,label = np.array(image) / 255.0,np.array(label)

    return image,label


def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    label = np.flip(label, axis=axis).copy()
    return image, label


def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label


class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):

        image, label = sample['image'], sample['label']

        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)

        x, y = image.shape

        if x != self.output_size[0] or y != self.output_size[1]:
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)  # why not 3?
            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)

        if random.random() > 0.5:
            image,label = random_affine_grayscale(image,label)
        else:
            image = normalize_to(image)
        #     image1_2,label1_2 = random_affine_grayscale(image1,label1)

        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample

class RandomGenerator2(object):
    def __init__(self, output_size):

        self.output_size = output_size

    def __call__(self, sample):
        # print("这是简单的数据增强")
        image, label = sample['image'], sample['label']

        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)
        x, y = image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)  # why not 3?
            image = normalize_to(image)


            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample


class ValGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']
        x, y = image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)  # why not 3?
            image = normalize_to(image)

            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample


class ACDC_dataset(Dataset):

    def __init__(self, base_dir, list_dir, split, transform=None,is_trans=True,transform2=None):
        self.transform = transform  # using transform in torch!
        self.split = split
        self.sample_list = open(os.path.join(list_dir, self.split+'.txt')).readlines()
        self.data_dir = base_dir
        self.is_trans =is_trans

        if transform2 is not None:
            self.transform2 = transform2


    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):

        if self.split == "train" or self.split == "valid":
            slice_name = self.sample_list[idx].strip('\n')
            data_path = os.path.join(self.data_dir, self.split, slice_name)
            data = np.load(data_path)
            image, label = data['img'], data['label']
        else:
            vol_name = self.sample_list[idx].strip('\n')
            filepath = os.path.join(self.data_dir, self.split, vol_name) 
            data = np.load(filepath)
            image, label = data['img'], data['label']

        image = (image + 1) / 2
        sample = {'image': image, 'label': label}
        if self.transform and self.split in ["train", "valid"]:
            if self.is_trans:
                sample = self.transform(sample)
            else:
                sample = self.transform2(sample)
        sample['case_name'] = self.sample_list[idx].strip('\n')
        return sample