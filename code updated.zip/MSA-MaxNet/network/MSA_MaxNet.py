import timm
import  torch
import copy
import torch.nn as nn
import einops
import math
from einops import rearrange, repeat
def get_layer_dims(model,image_size=(3,3,224,224)):
    input = torch.randn(image_size)
    out = model(input)
    out_dims=[]
    for i in out:
        out_dims.append(i.shape[1])
    print(out_dims)
    return out_dims
class LayerNormProxy(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        x = einops.rearrange(x, 'b c h w -> b h w c')
        x = self.norm(x)
        return einops.rearrange(x, 'b h w c -> b c h w')

class LinearPatchExpand2D(nn.Module):
    def __init__(self, dim, scale_factor=2,out=None, norm_layer=LayerNormProxy):
        super().__init__()
        self.dim = dim
        self.scale_factor = scale_factor
        self.output_dim = dim // scale_factor if scale_factor == 2 else dim

        self.expand = nn.Linear(dim, scale_factor * dim if scale_factor == 2 else (scale_factor ** 2) * dim,
                                bias=False) if scale_factor > 1 else nn.Identity()

        if out is not None and out != self.output_dim:
            self.shortcut = nn.Linear(self.output_dim, out, bias=False)
        else:
            self.shortcut =nn.Identity()
        self.norm = norm_layer(out if out is not None and out != self.output_dim else self.output_dim)
    def forward(self, x):
        """
        x: B, H*W, C
        """
        x = x.flatten(2).permute(0, 2, 1)
        x = self.expand(x)
        B, L, C = x.shape
        H, W = int(math.sqrt(L)), int(math.sqrt(L))
        assert L == H * W, "input feature has wrong size"

        x = x.view(B, H, W, C)
        x = rearrange(x, 'b h w (p1 p2 c)-> b (h p1) (w p2) c', p1=self.scale_factor, p2=self.scale_factor,
                      c=self.output_dim)
        x = x.reshape(B, H * self.scale_factor, W * self.scale_factor, self.output_dim)  # BxHxWxC
        x=self.shortcut(x)
        x = x.permute(0, 3, 1, 2)  # BxCxHxW
        x = self.norm(x)

        return x

class net1(nn.Module):
    def __init__(self, model_name="maxvit_rmlp_pico_rw_256.sw_in1k",num_classes=9,image_size=256):
        super().__init__()
        encoder = timm.create_model(model_name, pretrained=True,features_only=True)
        print(model_name)
        model_copy = copy.deepcopy(encoder)

        channels_per_output = get_layer_dims(encoder,image_size=(2,3,image_size,image_size))
        channels = channels_per_output[1:]
        stage_num = ["stages_0","stages_1","stages_2"]
        decoder = nn.ModuleList()
        concat_convs = nn.ModuleList()
        upsample_layers = nn.ModuleList()
        for idx,s in enumerate(stage_num):
            stage = getattr(model_copy,s,None)
            attn_blocks_list = nn.ModuleList()
            for i, block in enumerate(stage.blocks):
                atten = nn.Sequential(
                    block.attn_block,
                    block.attn_grid
                )
                attn_blocks_list.append(atten)
                # nn.Sequential(*module_list)
            decoder.append(nn.Sequential(*attn_blocks_list))
            concat_convs.append(nn.Conv2d(2 * channels[idx], channels[idx], kernel_size=1, bias=False))
            upsample_layers.append(LinearPatchExpand2D(channels[idx+1],out=channels[idx]))

        self.encoder=encoder
        self.decoder=decoder
        self.concat_convs=concat_convs
        self.upsample_layers=upsample_layers
        # self.decoder_num=3
        self.last_expand2d = LinearPatchExpand2D(channels[0], scale_factor=4)
        self.output = nn.Conv2d(in_channels=channels[0], out_channels=num_classes, kernel_size=1, bias=False)
    def forward(self, x):
        if x.size()[1] == 1:
            x = x.repeat(1,3,1,1)
        xx = self.encoder(x)
        x = xx[-1]
        for i in range(3):
            idx = 2-i
            x_en = xx[3 - i]
            x = self.upsample_layers[idx](x)
            x = self.concat_convs[idx](torch.cat([x,x_en],dim=1))
            B, H, W, C = x.shape
            x  = x.permute(0,2,3,1)
            x = self.decoder[idx](x)
            x = x.permute(0, 3, 1, 2)
        x = self.last_expand2d(x)
        x = self.output(x)
        # x = self.decoder_features(x)
        # x = self.forward_head(x)
        return x

class MCBAMLayer(nn.Module):
    def __init__(self, channel, reduction=16, spatial_kernel=7):
        super(MCBAMLayer, self).__init__()

        # channel attention 压缩H,W为1
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        # shared MLP
        self.mlp = nn.Sequential(
            # Conv2d比Linear方便操作
            # nn.Linear(channel, channel // reduction, bias=False)
            nn.Conv2d(channel[2], channel[1], 1, bias=False),
            # inplace=True直接替换，节省内存
            nn.ReLU(inplace=True)
            # nn.Linear(channel // reduction, channel,bias=False)
        )
        self.conv=nn.Sequential(
            nn.Conv2d(channel[0],1,2,2),
            nn.BatchNorm2d(1),
        )
        # spatial attention
        # self.conv = nn.Conv2d(2, 1, kernel_size=spatial_kernel,
        #                       padding=spatial_kernel // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x0,x,x1):
        max_out = self.mlp(self.max_pool(x1))
        avg_out = self.mlp(self.avg_pool(x1))
        channel_out = self.sigmoid(max_out + avg_out)
        x = channel_out * x
        spatial_out = self.sigmoid(self.conv(x0))
        x = spatial_out * x
        return x
class CBAMLayer(nn.Module):
    def __init__(self, channel, reduction=16, spatial_kernel=7):
        super(CBAMLayer, self).__init__()

        # channel attention 压缩H,W为1
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        # shared MLP
        self.mlp = nn.Sequential(
            # Conv2d比Linear方便操作
            # nn.Linear(channel, channel // reduction, bias=False)
            nn.Conv2d(channel, channel // reduction, 1, bias=False),
            # inplace=True直接替换，节省内存
            nn.ReLU(inplace=True),
            # nn.Linear(channel // reduction, channel,bias=False)
            nn.Conv2d(channel // reduction, channel, 1, bias=False)
        )

        # spatial attention
        self.conv = nn.Conv2d(2, 1, kernel_size=spatial_kernel,
                              padding=spatial_kernel // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out = self.mlp(self.max_pool(x))
        avg_out = self.mlp(self.avg_pool(x))
        channel_out = self.sigmoid(max_out + avg_out)
        x = channel_out * x

        max_out, _ = torch.max(x, dim=1, keepdim=True)
        avg_out = torch.mean(x, dim=1, keepdim=True)
        spatial_out = self.sigmoid(self.conv(torch.cat([max_out, avg_out], dim=1)))
        x = spatial_out * x
        return x

class net(nn.Module):
    def __init__(self, model_name="maxvit_rmlp_pico_rw_256.sw_in1k",num_classes=9,image_size=256):
        super().__init__()
        encoder = timm.create_model(model_name, pretrained=True,features_only=True)
        print(model_name)
        model_copy = copy.deepcopy(encoder)

        channels_per_output = get_layer_dims(encoder,image_size=(2,3,image_size,image_size))
        channels = channels_per_output[1:]
        stage_num = ["stages_0","stages_1","stages_2"]
        decoder = nn.ModuleList()
        concat_convs = nn.ModuleList()
        MCBAM_layers = nn.ModuleList()
        upsample_layers = nn.ModuleList()
        for idx,s in enumerate(stage_num):
            stage = getattr(model_copy,s,None)
            attn_blocks_list = nn.ModuleList()
            for i, block in enumerate(stage.blocks):
                atten = nn.Sequential(
                    block.attn_block,
                    block.attn_grid
                )
                attn_blocks_list.append(atten)
                # nn.Sequential(*module_list)
            decoder.append(nn.Sequential(*attn_blocks_list))
            concat_convs.append(nn.Conv2d(2 * channels[idx], channels[idx], kernel_size=1, bias=False))
            MCBAM_layers.append(MCBAMLayer((channels_per_output[idx],channels_per_output[idx+1],channels_per_output[idx+2])))
            upsample_layers.append(LinearPatchExpand2D(channels[idx+1],out=channels[idx]))
        self.MCBAM_layers = MCBAM_layers
        self.last_CBAM=CBAMLayer(channels_per_output[-1])
        self.encoder=encoder
        self.decoder=decoder
        self.concat_convs=concat_convs
        self.upsample_layers=upsample_layers
        # self.decoder_num=3
        self.last_expand2d = LinearPatchExpand2D(channels[0], scale_factor=4)
        self.output = nn.Conv2d(in_channels=channels[0], out_channels=num_classes, kernel_size=1, bias=False)
    def forward(self, x):
        if x.size()[1] == 1:
            x = x.repeat(1,3,1,1)
        xx = self.encoder(x)
        x = self.last_CBAM(xx[-1])

        for i in range(3):
            idx = 2-i
            x_en = self.MCBAM_layers[idx](xx[2-i],xx[3 - i],xx[4-i])
            x = self.upsample_layers[idx](x)
            x = self.concat_convs[idx](torch.cat([x,x_en],dim=1))
            B, H, W, C = x.shape
            x  = x.permute(0,2,3,1)
            x = self.decoder[idx](x)
            x = x.permute(0, 3, 1, 2)
        x = self.last_expand2d(x)
        x = self.output(x)
        # x = self.decoder_features(x)
        # x = self.forward_head(x)
        return x
# model=net1()
# input = torch.randn(1,3,256,256)
# out = model(input)
# print(out)