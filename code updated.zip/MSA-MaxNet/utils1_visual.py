import os
import time
import logging

import cv2
import numpy as np
import torch
from medpy import metric
from scipy.ndimage import zoom
import torch.nn as nn
import SimpleITK as sitk
from functools import partial
from multiprocessing import Pool
import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image
import cv2
# def colorize_segmentation(num, mask, image):
#     # 定义最多十种颜色的字典
#     # color_dict = {
#     #     0: [0, 0, 255],  # Blue
#     #     # 1: [0, 255, 0],  # Green
#     #     1: [124, 124, 186],  # Green
#     #     2: [63, 160, 192],  # Red
#     #     3: [181, 84, 137],  # Cyan
#     #     4: [0, 166, 100],  # Magenta
#     #     5: [220, 225, 37],  # Yellow
#     #     6: [240, 161, 154],  # Maroon
#     #     7: [214, 224, 200],  # Dark Green
#     #     8: [213, 217, 229],  # Navy
#     #     9: [76, 108, 67]  # Oliveprediction
#     # }
#     color_dict = {
#         0: [0, 0, 0],  # Blue
#         # 1: [0, 255, 0],  # Green
#         1: [231, 79, 76],  # Green
#         2: [37, 225, 219],  # Red
#         3: [255, 230, 153],  # Cyan
#         4: [70, 105, 234],  # Magenta
#         5: [154, 161, 240],  # Yellow
#         6: [123, 209, 68],  # Maroon
#         7: [237, 151, 69],  # Dark Green
#         # 8: [234, 234, 234],  # Navy
#         8: [232, 85, 164],  # Navy
#         # 9: [76, 108, 67]  # Oliveprediction
#     }
#
#     # 确保num不超过颜色字典的大小
#     assert num <= len(color_dict), "num不能超过颜色字典的大小"
#
#     batch_size, h, w = image.shape
#
#     # 创建一个彩色图像数组，初始化为原始灰度图像的三通道版本
#     color_images = np.zeros((batch_size, h, w, 3), dtype=np.uint8)
#
#     for b in range(batch_size):
#         color_images[b] = np.stack([image[b]] * 3, axis=-1)
#         # 对每个batch中的图像进行处理
#         for i in range(num ):
#             if i==0:
#                 continue
#             # 获取当前类别的颜色
#             color = color_dict[i]
#
#             # 找到mask中当前类别的位置
#             mask_region = (mask[b] == i)
#
#             # 对原图中mask区域赋予对应颜色
#             for c in range(3):  # 对R, G, B三个通道分别赋值
#                 color_images[b, :, :, c][mask_region] = color[c]
#
#     return color_images

def visualize_image(image, title=None):
    """
    Visualize an image, whether it's in PIL, numpy, or torch.Tensor format.

    Args:
        image: The image to visualize. Can be a PIL.Image, numpy array, or torch.Tensor.
        title: Optional title for the image.
    """
    if isinstance(image, Image.Image):  # If the image is a PIL image
        plt.imshow(image)
        plt.axis('off')

    elif isinstance(image, np.ndarray):  # If the image is a numpy array
        if image.ndim == 2:  # Grayscale image
            plt.imshow(image, cmap='gray')
        else:
            plt.imshow(image)
        plt.axis('off')

    elif isinstance(image, torch.Tensor):  # If the image is a torch.Tensor
        if image.ndimension() == 3:
            # Assume the tensor is in CxHxW format (e.g., 3x224x224 for color image)
            image = image.permute(1, 2, 0)  # Convert to HxWxC for visualization
        image = image.cpu().numpy()  # Convert to numpy for plotting
        if image.ndim == 2:  # Grayscale image
            plt.imshow(image, cmap='gray')
        else:
            plt.imshow(image)
        plt.axis('off')

    else:
        raise TypeError("Unsupported image type. Must be PIL, numpy, or torch.Tensor.")

    if title:
        plt.title(title)
    plt.show()
def colorize_segmentation(num, mask, image, alpha=1):
    # 定义最多十种颜色的字典
    #SEGNET
    color_dict = {
        0: [0, 0, 0],  # Black
        1: [231, 79, 76],  # Red
        2: [37, 225, 219],  # Cyan
        3: [255, 230, 153],  # Yellow
        4: [70, 105, 234],  # Blue
        5: [154, 161, 240],  # Light Blue
        6: [123, 209, 68],  # Green
        7: [237, 151, 69],  # Orange
        8: [232, 85, 164],  # Pink
    }
    # color_dict = {
    #     0: [0, 0, 0],  # Black
    #     1: [200, 224, 214],  # Red
    #     2: [100, 166, 0],  # Cyan
    #     3: [137, 84, 181],  # Yellow
    #     4: [192, 160, 15],  # Blue
    #     5: [37, 225, 219],  # Light Blue
    #     6: [219, 217, 213],  # Green
    #     7: [186, 124, 124],  # Orange
    #     8: [154, 161, 240],  # Pink
    # }

    color_dict = {
        0: [0, 0, 0],  # Black
        7: [200, 224, 214],  # Red
        4: [100, 166, 0],  # Cyan
        3: [137, 84, 181],  # Yellow
        2: [192, 160, 15],  # Blue
        5: [37, 225, 219],  # Light Blue
        8: [229, 217, 213],  # Green
        1: [186, 124, 124],  # Orange
        6: [154, 161, 240],  # Pink
    }



    # color_dict = {
    #         0: [0, 0, 255],  # Blue
    #         # 1: [0, 255, 0],  # Green
    #         1: [124, 124, 186],  # Green
    #         2: [63, 160, 192],  # Red
    #         3: [181, 84, 137],  # Cyan
    #         4: [0, 166, 100],  # Magenta
    #         5: [220, 225, 37],  # Yellow
    #         6: [240, 161, 154],  # Maroon
    #         7: [214, 224, 200],  # Dark Green
    #         8: [213, 217, 229],  # Navy
    #         9: [76, 108, 67]  # Oliveprediction
    #     }

    # ACDC
    # color_dict = {
    #     0: [0, 0, 0],  # Black
    #     # 1: [231, 79, 76],  # Red
    #     # 2: [37, 225, 219],  # Cyan
    #     # 3: [255, 230, 153],  # Yellow
    #     2: [70, 105, 234],  # Blue
    #     # 5: [154, 161, 240],  # Light Blue
    #     # 6: [123, 209, 68],  # Green
    #     1: [237, 151, 69],  # Orange
    #     3: [232, 85, 164],  # Pink
    # }

    # 确保num不超过颜色字典的大小
    assert num <= len(color_dict), "num不能超过颜色字典的大小"

    batch_size, h, w = image.shape

    # 创建一个彩色图像数组，初始化为原始灰度图像的三通道版本
    color_images = np.zeros((batch_size, h, w, 3), dtype=np.uint8)

    # 对每个batch中的图像进行处理
    for b in range(batch_size):
        # 将原始图像堆叠为三通道
        color_images[b] = np.stack([image[b]] * 3, axis=-1)

        # 对每个类应用颜色，使用alpha进行透明度填充
        for i in range(1, num):
            # 获取当前类别的颜色
            color = np.array(color_dict[i], dtype=np.float32)

            # 找到mask中当前类别的位置
            mask_region = (mask[b] == i)

            # 对原图中mask区域赋予对应颜色，并应用alpha混合
            for c in range(3):  # 对R, G, B三个通道分别赋值
                color_images[b, :, :, c][mask_region] = (
                        alpha * color[c] + (1 - alpha) * color_images[b, :, :, c][mask_region]
                ).astype(np.uint8)

    return color_images


class DiceLoss(nn.Module):
    def __init__(self, n_classes):
        super(DiceLoss, self).__init__()
        self.n_classes = n_classes

    def _one_hot_encoder(self, input_tensor):
        tensor_list = []
        for i in range(self.n_classes):
            temp_prob = input_tensor == i  # * torch.ones_like(input_tensor)
            tensor_list.append(temp_prob.unsqueeze(1))
        output_tensor = torch.cat(tensor_list, dim=1)
        return output_tensor.float()

    def _dice_loss(self, score, target):
        target = target.float()
        smooth = 1e-5
        intersect = torch.sum(score * target)
        y_sum = torch.sum(target * target)
        z_sum = torch.sum(score * score)
        loss = (2 * intersect + smooth) / (z_sum + y_sum + smooth)
        loss = 1 - loss
        return loss

    def forward(self, inputs, target, weight=None, softmax=False):
        if softmax:
            inputs = torch.softmax(inputs, dim=1)
        target = self._one_hot_encoder(target)
        if weight is None:
            weight = [1] * self.n_classes
        assert inputs.size() == target.size(), 'predict {} & target {} shape do not match'.format(inputs.size(), target.size())
        class_wise_dice = []
        loss = 0.0
        for i in range(0, self.n_classes):
            dice = self._dice_loss(inputs[:, i], target[:, i])
            class_wise_dice.append(1.0 - dice.item())
            loss += dice * weight[i]
        return loss / self.n_classes

def calculate_metric_percase(pred, gt):
    pred[pred > 0] = 1
    gt[gt > 0] = 1
    if pred.sum() > 0 and gt.sum()>0:
        dice = metric.binary.dc(pred, gt)
        hd95 = metric.binary.hd95(pred, gt)
        return dice, hd95
    elif pred.sum() > 0 and gt.sum()==0:
        return 1, 0
    else:
        return 0, 0

def calculate_metric_list_percase(pred, gt, classes=9):
    metric_list = []
    for i in range(1, classes):
        metric_list.append(calculate_metric_percase(pred == i, gt == i))
    return np.array(metric_list)

def calculate_metric_multicases(preds, gts, classes=9, num_workers=12):
    with Pool(num_workers) as p:
        metrics_list = p.starmap(partial(calculate_metric_list_percase, classes=classes), zip(preds, gts))
    metrics_list = np.array(metrics_list)
    metrics_list = metrics_list.mean(axis=0) # 8x2
    return metrics_list
def normalize_to(image):
    """
    将任意范围内的 numpy 数组线性映射为 [0, 255] 的整数值。

    Args:
        image (np.ndarray): 输入的 numpy 数组，值在任意范围内。

    Returns:
        np.ndarray: 转换后的 [0, 255] 范围内的 uint8 类型的 numpy 数组。
    """
    # 计算输入数据的最小值和最大值
    min_val = np.min(image)
    max_val = np.max(image)

    # 线性归一化，将任意范围的值映射到 [0, 255]
    image_normalized = (image - min_val) / (max_val - min_val)

    # 将结果转换为 uint8 类型
    return image_normalized

import time
def test_single_volume(image, label, net, classes, patch_size=[256, 256], test_save_path=None, case=None, z_spacing=1):
    image, label = image.squeeze(0).cpu().detach().numpy(), label.squeeze(0).cpu().detach().numpy()
    if len(image.shape) == 3:
        prediction = np.zeros_like(label)
        for ind in range(image.shape[0]):
            slice = image[ind, :, :]
            x, y = slice.shape[0], slice.shape[1]
            if x != patch_size[0] or y != patch_size[1]:
                slice = zoom(slice, (patch_size[0] / x, patch_size[1] / y), order=3)  # previous using 0
                slice = normalize_to(slice)
                # image[ind] =  normalize_to(image[ind])
            input = torch.from_numpy(slice).unsqueeze(0).unsqueeze(0).float().cuda()
            start_time = time.time()
            net.eval()
            with torch.no_grad():
                outputs = net(input)
                out = torch.argmax(torch.softmax(outputs, dim=1), dim=1).squeeze(0)
                out = out.cpu().detach().numpy()
                if x != patch_size[0] or y != patch_size[1]:
                    pred = zoom(out, (x / patch_size[0], y / patch_size[1]), order=0)
                else:
                    pred = out
                prediction[ind] = pred
            end_time = time.time()
            # print(f"时间：{start_time-end_time}")
    else:
        input = torch.from_numpy(image).unsqueeze(
            0).unsqueeze(0).float().cuda()
        net.eval()
        with torch.no_grad():
            out = torch.argmax(torch.softmax(net(input), dim=1), dim=1).squeeze(0)
            prediction = out.cpu().detach().numpy()
    metric_list = []

    pred_mask = colorize_segmentation(classes, prediction, image * 255)
    ture_mask = colorize_segmentation(classes, label, image * 255)
    out_root = test_save_path + '/' + str(case)
    os.makedirs(out_root, exist_ok=True)
    for i in range(len(image)):
        out1 = out_root + f"/pred_{str(i)}.png"
        out2 = out_root + f"/true_{str(i)}.png"
        cv2.imwrite(out1, cv2.cvtColor(pred_mask[i], cv2.COLOR_RGB2BGR))
        cv2.imwrite(out2, cv2.cvtColor(ture_mask[i], cv2.COLOR_RGB2BGR))

        # cv2.imwrite(out1, pred_mask[i])
        # cv2.imwrite(out2, ture_mask[i])

    for i in range(1, classes):
        metric_list.append(calculate_metric_percase(prediction == i, label == i))

    # if test_save_path is not None:
    #     img_itk = sitk.GetImageFromArray(image.astype(np.float32))
    #     prd_itk = sitk.GetImageFromArray(prediction.astype(np.float32))
    #     lab_itk = sitk.GetImageFromArray(label.astype(np.float32))
    #     img_itk.SetSpacing((1, 1, z_spacing))
    #     prd_itk.SetSpacing((1, 1, z_spacing))
    #     lab_itk.SetSpacing((1, 1, z_spacing))
    #     sitk.WriteImage(prd_itk, test_save_path + '/'+case + "_pred.nii.gz")
    #     sitk.WriteImage(img_itk, test_save_path + '/'+ case + "_img.nii.gz")
    #     sitk.WriteImage(lab_itk, test_save_path + '/'+ case + "_gt.nii.gz")
    return metric_list

def get_logger(filename, verbosity=1, name=None):
    level_dict = {0: logging.DEBUG, 1: logging.INFO, 2: logging.WARNING}
    formatter = logging.Formatter(
        "[%(asctime)s][%(filename)s][line:%(lineno)d][%(levelname)s] %(message)s"
    )
    logger = logging.getLogger(name)
    logger.setLevel(level_dict[verbosity])
    
    fh = logging.FileHandler(filename, "w")
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    
    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(sh)
    
    return logger

def maybe_mkdir_p(directory: str) -> None:
    os.makedirs(directory, exist_ok=True)

def make_dirs_by_time(save_dir):
    version = str(time.time())
    save_dir = join(save_dir, f"exp_{version}")
    if not os.path.exists(save_dir):
        maybe_mkdir_p(save_dir)

    return save_dir

join = os.path.join