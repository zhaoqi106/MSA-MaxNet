# MSA-MaxNet
This repository contains official implementation for the paper titled "MSA-MaxNet: Multi-scale Attention Enhanced Multi-Axis Vision Transformer Network for Medical Image Segmentation"


### Architecture
![model](figures/model.jpg)

### visualization of synapse

![visualization](figures/synapse_visualization.jpg)



## 1. Prepare data

- [Synapse multi-organ segmentation] The Synapse datasets we used are provided by TransUnet's authors. [Get processed data in this link] (https://drive.google.com/drive/folders/1ACJEoTp-uqfFJ73qS3eUObQh52nGuzCd). 
- [ACDC cardiac segmentation]


Put pretrained weights into folder **"data/"** under the main "MSA-MaxNet" directory, e.g., **"data/Synapse"**, **"data/ACDC"**.

## 2. Environment
- We recommend an evironment with python >= 3.8, pytorch >=2.0.0.

## 3. Train 
you need download pre-trained MaxVit weights from [maxvit_rmlp_small_rw_224_sw-6ef0ae4f.pth](https://drive.google.com/drive/folders/1k-s75ZosvpRGZEWl9UEpc_mniK3nL2xq)

Put pretrained weights into folder **"pretrained_ckpt/"** under the main "MSA-MaxNet" directory

### Run the training script
```
python train.py --root_path [path of dataset]
```
For example, for Synapse dataset, run the following command:
```
python train.py --root_path ./data/Synapse
```
For ACDC dataset, run the following command:
```
python train_acdc.py --root_path ./data/ACDC
```

## 4. Evaluate Pretrained Models
### Run the evaluating script
```
python test.py --volume_path [path of dataset] --save_checkpoint [path of trained checkpoint]
```
For example, for Synapse dataset, run the following command:
```
python test.py --volume_path ./data/Synapse --save_checkpoint ./trained_ckpt/out/best_train_model.pth
```
For ACDC dataset, run the following command:
```
python test_acdc.py --volume_path ./data/ACDC --save_checkpoint ./trained_ckpt/out/best_model.pth
```


## Acknowledgements

This code is built on the top of [Swin UNet](https://github.com/HuCaoFighting/Swin-Unet)、[MERIT](https://github.com/SLDGroup/MERIT) and [AgileFormer](https://github.com/sotiraslab/AgileFormer) , we thank to their efficient and neat codebase. 


