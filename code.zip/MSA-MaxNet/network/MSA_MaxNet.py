
import os.path

from network.models_timm.layers import create_attn, get_act_layer, get_norm_layer, get_norm_act_layer, create_conv2d

import torch.nn as nn
import torch
from typing import Callable, Optional, Union, Tuple, List
from network.maxxvit_4out import _rw_max_cfg,MaxxVitCfg,cfg_window_size,Stem,MaxxVitStage,MbConvBlock
from network.models_timm.layers import to_2tuple
import copy
import einops
import math
from einops import rearrange, repeat

class LayerNormProxy(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        x = einops.rearrange(x, 'b c h w -> b h w c')
        x = self.norm(x)
        return einops.rearrange(x, 'b h w c -> b c h w')
class LinearPatchExpand2D(nn.Module):
    def __init__(self, dim, scale_factor=2,out=None, norm_layer=LayerNormProxy):
        super().__init__()
        self.dim = dim
        self.scale_factor = scale_factor
        self.output_dim = dim // scale_factor if scale_factor == 2 else dim

        self.expand = nn.Linear(dim, scale_factor * dim if scale_factor == 2 else (scale_factor ** 2) * dim,
                                bias=False) if scale_factor > 1 else nn.Identity()

        if out is not None and out != self.output_dim:
            self.shortcut = nn.Linear(self.output_dim, out, bias=False)
        else:
            self.shortcut =nn.Identity()
        self.norm = norm_layer(out if out is not None and out != self.output_dim else self.output_dim)
    def forward(self, x):
        """
        x: B, H*W, C
        """
        x = x.flatten(2).permute(0, 2, 1)
        x = self.expand(x)
        B, L, C = x.shape
        H, W = int(math.sqrt(L)), int(math.sqrt(L))
        assert L == H * W, "input feature has wrong size"

        x = x.view(B, H, W, C)
        x = rearrange(x, 'b h w (p1 p2 c)-> b (h p1) (w p2) c', p1=self.scale_factor, p2=self.scale_factor,
                      c=self.output_dim)
        x = x.reshape(B, H * self.scale_factor, W * self.scale_factor, self.output_dim)  # BxHxWxC
        x=self.shortcut(x)
        x = x.permute(0, 3, 1, 2)  # BxCxHxW
        x = self.norm(x)

        return x
class MCBAMLayer(nn.Module):
    def __init__(self, channel, reduction=16, spatial_kernel=7):
        super(MCBAMLayer, self).__init__()

        # channel attention 压缩H,W为1
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        # shared MLP
        self.mlp = nn.Sequential(
            # Conv2d比Linear方便操作
            # nn.Linear(channel, channel // reduction, bias=False)
            nn.Conv2d(channel[2], channel[1], 1, bias=False),
            # inplace=True直接替换，节省内存
            nn.ReLU(inplace=True)
            # nn.Linear(channel // reduction, channel,bias=False)
        )
        self.conv=nn.Sequential(
            nn.Conv2d(channel[0],1,2,2),
            nn.BatchNorm2d(1),
        )
        # spatial attention
        # self.conv = nn.Conv2d(2, 1, kernel_size=spatial_kernel,
        #                       padding=spatial_kernel // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x0,x,x1):
        max_out = self.mlp(self.max_pool(x1))
        avg_out = self.mlp(self.avg_pool(x1))
        channel_out = self.sigmoid(max_out + avg_out)
        x = channel_out * x
        spatial_out = self.sigmoid(self.conv(x0))
        x = spatial_out * x
        return x
class CBAMLayer(nn.Module):
    def __init__(self, channel, reduction=16, spatial_kernel=7):
        super(CBAMLayer, self).__init__()

        # channel attention 压缩H,W为1
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)

        # shared MLP
        self.mlp = nn.Sequential(
            # Conv2d比Linear方便操作
            # nn.Linear(channel, channel // reduction, bias=False)
            nn.Conv2d(channel, channel // reduction, 1, bias=False),
            # inplace=True直接替换，节省内存
            nn.ReLU(inplace=True),
            # nn.Linear(channel // reduction, channel,bias=False)
            nn.Conv2d(channel // reduction, channel, 1, bias=False)
        )

        # spatial attention
        self.conv = nn.Conv2d(2, 1, kernel_size=spatial_kernel,
                              padding=spatial_kernel // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out = self.mlp(self.max_pool(x))
        avg_out = self.mlp(self.avg_pool(x))
        channel_out = self.sigmoid(max_out + avg_out)
        x = channel_out * x

        max_out, _ = torch.max(x, dim=1, keepdim=True)
        avg_out = torch.mean(x, dim=1, keepdim=True)
        spatial_out = self.sigmoid(self.conv(torch.cat([max_out, avg_out], dim=1)))
        x = spatial_out * x
        return x
class MSA_MaxNet(nn.Module):
    """ CoaTNet + MaxVit base model.

    Highly configurable for different block compositions, tensor layouts, pooling types.
    """

    def __init__(
            self,
            cfg: MaxxVitCfg,
            img_size: Union[int, Tuple[int, int]] = 224,
            in_chans: int = 3,
            num_classes: int = 1000,
            global_pool: str = 'avg',
            drop_rate: float = 0.,
            drop_path_rate: float = 0.6
    ):
        super().__init__()
        img_size = to_2tuple(img_size)
        transformer_cfg = cfg_window_size(cfg.transformer_cfg, img_size)
        self.num_classes = num_classes
        self.global_pool = global_pool
        self.num_features = cfg.embed_dim[-1]
        self.embed_dim = cfg.embed_dim
        self.drop_rate = drop_rate
        self.grad_checkpointing = False

        self.stem = Stem(
            in_chs=in_chans,
            out_chs=cfg.stem_width,
            act_layer=cfg.conv_cfg.act_layer,
            norm_layer=cfg.conv_cfg.norm_layer,
            norm_eps=cfg.conv_cfg.norm_eps,
        )

        stride = self.stem.stride
        feat_size = tuple([i // s for i, s in zip(img_size, to_2tuple(stride))])

        num_stages = len(cfg.embed_dim)
        assert len(cfg.depths) == num_stages
        dpr = [x.tolist() for x in torch.linspace(0, drop_path_rate, sum(cfg.depths)).split(cfg.depths)]
        in_chs = self.stem.out_chs

        stages = []
        # norms = []
        for i in range(num_stages):
            stage_stride = 2
            out_chs = cfg.embed_dim[i]
            feat_size = tuple([(r - 1) // stage_stride + 1 for r in feat_size])
            stages += [MaxxVitStage(
                in_chs,
                out_chs,
                depth=cfg.depths[i],
                block_types=cfg.block_type[i],
                conv_cfg=cfg.conv_cfg,
                transformer_cfg=transformer_cfg,
                feat_size=feat_size,
                drop_path=dpr[i],
            )]

            stride *= stage_stride
            in_chs = out_chs
        self.stages = nn.Sequential(*stages)

        final_norm_layer = get_norm_layer(cfg.transformer_cfg.norm_layer)
        self.norm = final_norm_layer(self.num_features, eps=cfg.transformer_cfg.norm_eps)

        self.stages_up= copy.deepcopy(self.stages)
        self.stages_up[-1] = nn.Identity()


        def recursive_remove(module):
            for name, child in list(module.named_children()):
                if isinstance(child, MbConvBlock):
                    # delattr(module,name)
                    setattr(module,name,nn.Identity())
                    # print(f"{name} delete from model")
                else:
                    recursive_remove(child)


        recursive_remove(self.stages_up)

        embed_dim = [cfg.stem_width[-1]] + list(cfg.embed_dim)
        embed_dim = cfg.embed_dim
        self.concat_convs = nn.ModuleList()
        self.CBAM = nn.ModuleList()
        self.downsample_layers = nn.ModuleList()
        for i_stage in range(num_stages):
            idx = num_stages - 1 - i_stage
            if i_stage ==0:
                self.CBAM.append(CBAMLayer(embed_dim[idx]))
            else:
                self.CBAM.append(MCBAMLayer((embed_dim[idx-1]  if idx != 0 else cfg.stem_width[-1],embed_dim[idx],embed_dim[idx+1])))
                self.downsample_layers.append(LinearPatchExpand2D(embed_dim[idx+1],out=embed_dim[idx]))
                self.concat_convs.append(nn.Conv2d(2*embed_dim[idx],embed_dim[idx],kernel_size=1,bias=False))
        self.last_expand2d = nn.Sequential(LayerNormProxy(embed_dim[0]),
                                           LinearPatchExpand2D(embed_dim[0], scale_factor=4))
        self.output = nn.Conv2d(in_channels=embed_dim[0],out_channels=num_classes,kernel_size=1,bias=False)

    @torch.no_grad()                                                                                      
    def load_pretrained(self, state_dict):
        new_state_dict = {}
        for state_key, state_value in state_dict.items():
            if "patch_proj" in state_key:
                new_state_dict[state_key] = state_value
            elif "down_projs" in state_key:
                new_state_dict[state_key] = state_value
            elif "cls_norm" in state_key:
                new_state_dict[state_key] = state_value
            elif "stages" in state_key and state_key in self.state_dict().keys():
                if self.state_dict()[state_key].shape == state_value.shape:
                    new_state_dict[state_key] = state_value
                    tmp = state_key.split(".")
                    num_depth = int(tmp[1])
                    if num_depth < 3:
                        new_state_key = ["stages_up", str( num_depth)] + tmp[2:]
                        new_state_key = ".".join(new_state_key)

                        try:
                            if self.state_dict()[new_state_key].shape == state_value.shape:
                                new_state_dict[new_state_key] = state_value
                            else:
                                pass
                        except:
                            pass
                else:
                    pass
            else:
                pass
        msg = self.load_state_dict(new_state_dict, strict=False)
        all_keys = set(new_state_dict.keys())
        missing_keys = set(msg.missing_keys)
        matched_keys = all_keys - missing_keys
        print("Successfully matched keys:",len(matched_keys))
        return msg

    def encoder_features(self, x):
        x = self.stem(x)
        # print(x.shape)
        # print(len(self.stages))
        features = []
        features.append(x)
        for i in range(len(self.stages)):
            x = self.stages[i](x)
            # print(x.shape)
            if (i == len(self.stages) - 1):
                features.append(self.norm(x))
            else:
                features.append(x)
        return features

    def decoder_features(self, x):
        x0 = x[-1].clone()
        seg_outputs = []
        for i in range(len(self.stages_up)):
            idx = len(self.stages_up)-1-i
            if i == 0:
                x0 = self.CBAM[i](x0)
            else:
                x0 = self.downsample_layers[i - 1](x0)
                x1 = self.CBAM[i](x[idx], x[idx+1], x[idx + 2])
                x0 = self.concat_convs[i-1](torch.cat([x0,x1], dim=1))
                x0 = self.stages_up[idx](x0)
        x0 = self.output(self.last_expand2d(x0))

        return x0

    def forward_head(self, x, pre_logits: bool = False):
        return self.head(x, pre_logits=pre_logits)

    def forward(self, x):
        x = self.encoder_features(x)
        x = self.decoder_features(x)
        # x = self.forward_head(x)
        return x


def load_pretrained(ckpt_path, model):
    checkpoint = torch.load(ckpt_path, map_location='cpu')
    msg = model.load_pretrained(checkpoint)
    del checkpoint
    torch.cuda.empty_cache()
def get_model(config,is_test=False):
    params = config["MODEL"]["Params"]
    net = MSA_MaxNet(cfg=maxvit_rmlp_small_rw_224[0],**params)
    if not is_test:
        assert os.path.exists(config["MODEL"]["PRETRAIN_CKPT"]),"PRETRAIN_CKPT is not exist"
        print("Loading pretrained model from {}".format(config["MODEL"]["PRETRAIN_CKPT"]))
        load_pretrained(config["MODEL"]["PRETRAIN_CKPT"],net)
    return net
maxvit_rmlp_small_rw_224=MaxxVitCfg(
        embed_dim=(96, 192, 384, 768),
        depths=(2, 2, 5, 2),
        block_type=('M',) * 4,
        stem_width=(32, 64),
        **_rw_max_cfg(
            rel_pos_type='mlp',
            init_values=1e-6,
        ),
    ),

if __name__ == '__main__':
    net=get_model()
    input=torch.randn(1, 3, 224, 224)
    out=net(input)
    print(out.shape)



